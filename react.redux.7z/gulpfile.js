var gulp         = require('gulp');
//var autoprefixer = require('gulp-autoprefixer');
var babel        = require('gulp-babel');
//var browserSync  = require('browser-sync');
var concat       = require('gulp-concat');
var eslint       = require('gulp-eslint');
//var filter       = require('gulp-filter');
var newer        = require('gulp-newer');
//var notify       = require('gulp-notify');
//var plumber      = require('gulp-plumber');
//var reload       = browserSync.reload;
var sass         = require('gulp-sass');
var sourcemaps   = require('gulp-sourcemaps');
var webpack = require('webpack-stream');

var onError = function(err) {
  notify.onError({
    title:    "Error",
    message:  "<%= error %>",
  })(err);
  this.emit('end');
};

// Lint JS/JSX files
gulp.task('eslint', function() {
  return gulp.src('js/src/*')
    .pipe(eslint({
      baseConfig: {
        "ecmaVersion": 2015,
        "sourceType": "module",
        "ecmaFeatures": {
           "jsx": true
         }
      }
    }))
    .pipe(eslint.format())
    .pipe(eslint.failAfterError());
});

// Copy react.js and react-dom.js to assets/js/src/vendor
// only if the copy in node_modules is "newer"
gulp.task('copy-react', function() {
  return gulp.src('node_modules/react/dist/react.js')
    .pipe(newer('js/vendor/react.js'))
    .pipe(gulp.dest('js/vendor'));
});
gulp.task('copy-react-dom', function() {
  return gulp.src('node_modules/react-dom/dist/react-dom.js')
    .pipe(newer('js/vendor/react-dom.js'))
    .pipe(gulp.dest('js/vendor'));
});

// Concatenate jsFiles.vendor and jsFiles.source into one JS file.
// Run copy-react and eslint before concatenating
gulp.task('concat-vendor', ['copy-react', 'copy-react-dom', 'eslint'], function() {
  return gulp.src('js/vendor/*')
    .pipe(sourcemaps.init())
    .pipe(concat('vendor.js'))
    .pipe(sourcemaps.write('./'))
    .pipe(gulp.dest('js/build/'));
});

gulp.task('concat-app', ['copy-react', 'copy-react-dom', 'eslint'], function() {
  return gulp.src('js/src/*')
    .pipe(sourcemaps.init())
    .pipe(babel({
      only: [
        'js/src/*'
      ],
      presets: ['es2015', 'react'],
      compact: false
    }))
    .pipe(concat('app.js'))
    .pipe(webpack())
    .pipe(sourcemaps.write('./'))
    .pipe(gulp.dest('js/build/'));
});

//.pipe(concat('app.js'))

// Compile Sass to CSS
//gulp.task('sass', function() {
//  var autoprefixerOptions = {
//    browsers: ['last 2 versions'],
//  };
//
//  var filterOptions = '**/*.css';
//
//  var reloadOptions = {
//    stream: true,
//  };
//
//  var sassOptions = {
//    includePaths: [
//
//    ]
//  };
//
//  return gulp.src('assets/sass/**/*.scss')
//    .pipe(plumber(plumberOptions))
//    .pipe(sourcemaps.init())
//    .pipe(sass(sassOptions))
//    .pipe(autoprefixer(autoprefixerOptions))
//    .pipe(sourcemaps.write('./'))
//    .pipe(gulp.dest('assets/css'))
//    .pipe(filter(filterOptions))
//    .pipe(reload(reloadOptions));
//});

// Watch JS/JSX and Sass files
gulp.task('watch', function() {
  gulp.watch('js/src/**/*.{js,jsx}', ['concat-app']);
  gulp.watch('js/src/*.{js,jsx}', ['concat-app']);
  //gulp.watch('sass/**/*.scss', ['sass']);
});

// BrowserSync
//gulp.task('browsersync', function() {
//  browserSync({
//    server: {
//      baseDir: './'
//    },
//    open: false,
//    online: false,
//    notify: false,
//  });
//});

//gulp.task('build', ['sass', 'copy-js-vendor', 'concat']);
gulp.task('build', ['eslint', 'copy-react', 'copy-react-dom', 'concat-vendor', 'concat-app']);
//gulp.task('default', ['build', 'browsersync', 'watch']);
gulp.task('default', ['build', 'watch']);