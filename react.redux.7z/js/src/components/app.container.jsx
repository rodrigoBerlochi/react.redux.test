'use strict';

import React from 'react';
//import {Container} from 'flux/utils'
import AppStore from '../stores/app.store';
import Form from './form.component';

/*class _container extends React.Component {
  static getStores() {
    return [MainStore];
  }
  static calculateState(prevState) {
    return {
      data: prevState || []
    };
  }
  render() {
    return <Form data={this.state.data} />;
  }
};
*/
//const container = Container.create(_container);

//export default container;